export interface UserInterfaceTs {
}
