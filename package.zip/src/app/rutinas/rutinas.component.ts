import { Component } from '@angular/core';

@Component({
  selector: 'app-rutinas',
  imports: [],
  templateUrl: './rutinas.component.html',
  styleUrl: './rutinas.component.scss'
})
export class RutinasComponent {

}
