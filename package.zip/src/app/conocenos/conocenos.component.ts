import { Component } from '@angular/core';

@Component({
  selector: 'app-conocenos',
  imports: [],
  templateUrl: './conocenos.component.html',
  styleUrl: './conocenos.component.scss'
})
export class ConocenosComponent {

}
