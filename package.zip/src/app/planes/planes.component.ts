import { Component } from '@angular/core';

@Component({
  selector: 'app-planes',
  imports: [],
  templateUrl: './planes.component.html',
  styleUrl: './planes.component.scss'
})
export class PlanesComponent {

}
