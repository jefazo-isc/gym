import { Component } from '@angular/core';

@Component({
  selector: 'app-carrusel-principal',
  imports: [],
  templateUrl: './carrusel-principal.component.html',
  styleUrl: './carrusel-principal.component.scss'
})
export class CarruselPrincipalComponent {

}
