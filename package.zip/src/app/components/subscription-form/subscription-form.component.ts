import { Component } from '@angular/core';

@Component({
  selector: 'app-subscription-form',
  imports: [],
  templateUrl: './subscription-form.component.html',
  styleUrl: './subscription-form.component.scss'
})
export class SubscriptionFormComponent {

}
