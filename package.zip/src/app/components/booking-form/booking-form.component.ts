import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-form',
  imports: [],
  templateUrl: './booking-form.component.html',
  styleUrl: './booking-form.component.scss'
})
export class BookingFormComponent {

}
