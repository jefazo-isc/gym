import { Component } from '@angular/core';

@Component({
  selector: 'app-classes',
  imports: [],
  templateUrl: './classes.component.html',
  styleUrl: './classes.component.scss'
})
export class ClassesComponent {

}
