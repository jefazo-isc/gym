import { Component } from '@angular/core';

@Component({
  selector: 'app-cards-principal',
  imports: [],
  templateUrl: './cards-principal.component.html',
  styleUrl: './cards-principal.component.scss'
})
export class CardsPrincipalComponent {

}
